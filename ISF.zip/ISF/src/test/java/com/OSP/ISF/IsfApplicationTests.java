package com.OSP.ISF;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IsfApplicationTests {

	@Test
	void contextLoads() {
	}

}
